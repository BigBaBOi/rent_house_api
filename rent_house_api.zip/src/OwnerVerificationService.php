<?php
class OwnerVerificationService {
    private $conn;

    public function __construct(PDO $conn) {
        $this->conn = $conn;
    }

    /**
     * ====== [FEATURE 2: OWNER VERIFICATION SYSTEM] ======
     * Tạo request xác thực cho chủ trọ
     * Chủ trọ cần cung cấp: CMND/CCCD, ảnh khuôn mặt, giấy phép kinh doanh
     */
    public function createVerificationRequest(string $userId, array $ownerData): bool {
        try {
            $stmt = $this->conn->prepare(
                'INSERT INTO OwnerVerifications (owner_id, id_card_front_url, id_card_back_url, full_name_on_doc, id_number, business_license_url, status, created_at) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW())'
            );
            
            $stmt->execute([
                $userId,
                $ownerData['id_card_front_url'] ?? null,
                $ownerData['id_card_back_url'] ?? null,
                $ownerData['full_name_on_doc'] ?? null,
                $ownerData['id_number'] ?? null,
                $ownerData['business_license_url'] ?? null,
                'Pending'
            ]);

            return true;
        } catch (PDOException $e) {
            throw $e;
        }
    }

    /**
     * ====== [FEATURE 2B: GET VERIFICATION STATUS] ======
     * Lấy trạng thái xác thực của chủ trọ
     */
    public function getVerificationStatus(string $userId): ?array {
        $stmt = $this->conn->prepare(
            'SELECT * FROM OwnerVerifications WHERE owner_id = ? ORDER BY created_at DESC LIMIT 1'
        );
        $stmt->execute([$userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * ====== [FEATURE 2C: UPDATE VERIFICATION STATUS] ======
     * Cập nhật trạng thái xác thực (chỉ admin)
     * Trạng thái: Pending -> Approved/Rejected
     */
    public function updateVerificationStatus(string $verifyId, string $status, ?string $reviewNote = null, ?string $reviewedBy = null): bool {
        try {
            $stmt = $this->conn->prepare(
                'UPDATE OwnerVerifications SET status = ?, review_note = ?, reviewed_by = ? WHERE verify_id = ?'
            );
            
            $stmt->execute([
                $status,
                $reviewNote,
                $reviewedBy,
                $verifyId
            ]);

            if ($stmt->rowCount() > 0) {
                // Nếu xác thực thành công, cập nhật user status
                if ($status === 'Approved') {
                    $this->updateUserVerificationStatus($verifyId, 'Verified');
                } elseif ($status === 'Rejected') {
                    $this->updateUserVerificationStatus($verifyId, 'Unverified');
                }
            }

            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            throw $e;
        }
    }

    /**
     * Cập nhật trạng thái xác thực của user
     */
    private function updateUserVerificationStatus(string $verifyId, string $status): bool {
        try {
            $stmt = $this->conn->prepare(
                'UPDATE Users SET verification_status = ? 
                 WHERE user_id = (SELECT owner_id FROM OwnerVerifications WHERE verify_id = ?)'
            );
            
            return $stmt->execute([$status, $verifyId]) && $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            throw $e;
        }
    }

    /**
     * ====== [FEATURE 2D: GET PENDING VERIFICATIONS] ======
     * Lấy danh sách chủ trọ chờ xác thực
     * Dùng cho admin dashboard
     */
    public function getPendingVerifications(int $limit = 50, int $offset = 0): array {
        $stmt = $this->conn->prepare(
            'SELECT ov.*, u.email, u.full_name, u.phone_number 
             FROM OwnerVerifications ov
             JOIN Users u ON ov.owner_id = u.user_id
             WHERE ov.status = "Pending"
               AND u.role = "owner"
               AND u.verification_status = "Pending"
             ORDER BY ov.created_at ASC
             LIMIT :limit OFFSET :offset'
        );
        
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
